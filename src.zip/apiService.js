import axios from 'axios';

const apiBaseUrl = process.env.REACT_APP_BASE_URL; // Replace with your API base URL

export const apiService = axios.create({
    baseURL: apiBaseUrl,
});


export const getLocAnns = async (time) => {
    try {
        const { data } = await apiService.get(`/anns/loca/${"month"}?ses=${JSON.parse(localStorage.getItem("ses"))}`);
        if (data.status === "OK") {
            return data;
        } else {
            return console.log("Session is Expired");
        }
    } catch (error) {
        return console.log("Fetching Error:", error);
    }
}

export const getVenteAnns = async (time) => {
    try {
        const { data } = await apiService.get(`/anns/vent/${"month"}?ses=${JSON.parse(localStorage.getItem("ses"))}`);
        if (data.status === "OK") {
            return data;
        } else {
            return console.log("Session is Expired");
        }
    } catch (error) {
        return console.log("Fetching Error:", error);
    }
}

export const checkSession = async () => {
    try {
        const { data } = await apiService.get(`/age?ses=${JSON.parse(localStorage.getItem("ses"))}`);
        if (data.status === "KO") {
            return true;
        } else {
            return false;
        }
    } catch (error) {
        return console.log("Fetching Error:", error);
    }
}

export const getListCommunes = async () => {
    try {
        const { data } = await apiService.get(`/geo/getListeCommunes?sessionID=${JSON.parse(localStorage.getItem("ses"))}`);
        if (data.status === "OK") {
            return data.results;
        } else {
            return console.log("Session is Expired");
        }
    } catch (error) {
        return console.log("Fetching Error:", error);
    }
}

export const getInsee = async (insee) => {
    try {
        const { data } = await apiService.get(`geo/getContourCommune?sessionID=${JSON.parse(localStorage.getItem("ses"))}&insee=${insee}`);
        if (data.status === "OK" && data.geometry != null) {
            return data.geometry.coordinates[0];
        }
        if (data.geometry == null) {
            return false
        }
        else {
            return console.log("Session is Expired");
        }
    } catch (error) {
        return console.log("Fetching Error:", error);
    }
}